#include<iostream>
#include<stdlib.h>
#include<time.h>

#pragma once


enum class Ball { RED, LILA, BLUE, GREEN, YELLOW };

// int, float, 

int randomNumber(int min, int max);
